const currentTime = document.querySelector(".para");
const buttonParent = document.querySelector(".btn-container");
const para=document.querySelector(".para1");

let seconds = 0;
let minutes = 0;
let hours = 0;
let timerId;

function displayTime(hours, minutes, seconds) {
  currentTime.innerText = `${hours < 10 ? `0${hours}` : hours} : ${
    minutes < 10 ? `0${minutes}` : minutes
  } : ${seconds < 10 ? `0${seconds}` : seconds}`;
}

function handleButtonClick(event) {
  const button = event.target.name;
  if (button === "start") {
    timerId = setInterval(() => {
      seconds++;
      if (seconds > 58) {
        seconds = 0;
        minutes++;
        if (minutes > 58) {
          minutes = 0;
          hours++;
        }
      }
      displayTime(hours, minutes, seconds);
    }, 100);
    para.innerText="";
  }
  if (button === "stop") {
    
    clearInterval(timerId);
    para.innerText = `${hours < 10 ? `0${hours}` : hours} : ${
        minutes < 10 ? `0${minutes}` : minutes
      } : ${seconds < 10 ? `0${seconds}` : seconds}`;

  }
  if (button === "reset") {
    para.innerText="";
    clearInterval(timerId);
    seconds = minutes = hours = 0;
    displayTime(hours, minutes, seconds);
  }
}

buttonParent.addEventListener("click", handleButtonClick);