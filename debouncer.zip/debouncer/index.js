const input = document.querySelector(".input");
const beby = document.querySelector(".beby");

function inputHanlder(event) {
//   console.log(event.target.value);
beby.innerText=event.target.value;

}

function debounce(callback, delay) {
  let timerId;
  return function (...args) {
    clearTimeout(timerId);
    timerId = setTimeout(() => {
      callback(...args);
    }, delay);
  };
}

const deboouncedInputHandler = debounce(inputHanlder, 500);

input.addEventListener("keyup", deboouncedInputHandler);